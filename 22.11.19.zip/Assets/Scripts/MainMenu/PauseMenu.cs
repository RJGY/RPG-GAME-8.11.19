﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PauseMenu : MonoBehaviour
{
    public bool isPaused;
    public GameObject _pauseMenu;
    public event Action<bool> PausedMenu;

    void Start()
    {
        _pauseMenu = GameObject.FindGameObjectWithTag("PauseMenu");
        _pauseMenu.SetActive(false);
        isPaused = false;
        Time.timeScale = 1;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    void Update()
    {
        if (Input.GetButtonDown("Cancel"))
        {
            TogglePause();
        }
    }
    public void TogglePause()
    {
        if (isPaused)
        {
            if (PausedMenu != null)
            {
                PausedMenu(false);
            }
            isPaused = false;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            Time.timeScale = 1;
            _pauseMenu.SetActive(false);

            
        }

        else
        {
            if (PausedMenu != null)
            {
                PausedMenu(true);
            }
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            Time.timeScale = 0;
            _pauseMenu.SetActive(true);
            isPaused = true;
        }
    }
}
