﻿using UnityEngine;

namespace RPG.Player
{
    [AddComponentMenu("RPG/Player/Movement")]
    [RequireComponent(typeof(CharacterController))]
    public class Movement : MonoBehaviour
    {
        [Header("Speed Vars")]
        //Value Variables
        public float moveSpeed;
        public float runSpeed, walkSpeed, crouchSpeed, jumpSpeed;
        private float _gravity = 20;
        public bool _isRunning = false, _isCrouching = false;
        private string _lastAction;

        //Struct - Contains Multiple Variables (eg...3 floats)
        private Vector3 _moveDir;

        //Reference Variable
        private CharacterController _charController;

        private void Start()
        {
            _charController = GetComponent<CharacterController>();
        }
        private void Update()
        {

            CheckSpecialMove();
            Move();
            
        }

        private void CheckSpecialMove()
        {
            // Check the last button press
            if (Input.GetButtonDown("Sprint"))
            {
                _lastAction = "Sprint";
            }

            if (Input.GetButton("Sprint"))
            {
                _isRunning = true;
            }
            

            if (Input.GetButtonDown("Crouch"))
            {
                
                _lastAction = "Crouch";
            }
            if (Input.GetButton("Crouch"))
            {
                _isCrouching = true;
            }

            if (Input.GetButtonUp("Sprint"))
            {
                _isRunning = false;

            }

            if (Input.GetButtonUp("Crouch"))
            {
                _isCrouching = false;
            }
        }

        private void Move()
        {
            if (!PlayerHandler.isDead)
            {
                if (_charController.isGrounded) 
                {

                    //set speed
                    if (_isRunning)
                    {
                        moveSpeed = runSpeed;
                    }
                    if (_isCrouching && _lastAction.Equals("Crouch"))
                    {
                        moveSpeed = crouchSpeed;
                    }
                    if (!_isRunning && !_isCrouching)
                    {
                        moveSpeed = walkSpeed;
                    }

                    // move this direction based off inputs
                    _moveDir = transform.TransformDirection(new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")) * moveSpeed);
                    if (Input.GetButton("Jump"))
                    {
                        _moveDir.y = jumpSpeed;
                    }
                }
            }
            else
            {
                _moveDir = new Vector3(Mathf.Lerp(_moveDir.x, 0, 2*Time.deltaTime), Mathf.Lerp(_moveDir.y, 0, 2 * Time.deltaTime), Mathf.Lerp(_moveDir.z, 0, 2 * Time.deltaTime));
            }
            
            // Regardless if we are grounded or not
            // apply grvity
            _moveDir.y -= _gravity * Time.deltaTime;
            //apply movement
            _charController.Move(_moveDir * Time.deltaTime);
        }
    }
}
