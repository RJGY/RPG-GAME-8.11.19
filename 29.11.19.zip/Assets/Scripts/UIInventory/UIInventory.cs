﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace RPG.Player
{
    public class UIInventory : MonoBehaviour
    {
        public static List<Item> inventory = new List<Item>();
        public static List<Button> parrallelButtonList = new List<Button>();
        public bool showInventory = false;
        public Item selectedItem;
        public Image selectedItemImage;
        public Text selectedItemTitle;
        public Text selectedItemDescription;
        public Button selectedItemDropButton;
        public Button selectedItemUseButton;
        public GameObject selectedItemBackground;
        public Dropdown dropdownFilter;

        public Vector2 screen;
        private bool isGamePaused = false;
        public bool inFilterOption;
        public GameObject buttonPrefab;
        public GameObject gridLayout;
        public Scrollbar scrollbar;
        private Vector3 origin;
        public static int money;
        public string sortType = "All";
        public Transform dropLocation;
        private PauseMenu pauseMenu;
        private KeyCode inventoryKey;

        public EquippedItems[] equippedItems;
        [System.Serializable]
        public struct EquippedItems
        {
            public string name;
            public Transform location;
            public GameObject equippedItem;
        }

        // Start is called before the first frame update
        void Start()
        {
            scrollbar.gameObject.SetActive(false);
            scrollbar.onValueChanged.AddListener((float value) => Scroll(value));
            selectedItemImage.gameObject.SetActive(false);
            selectedItemDescription.gameObject.SetActive(false);
            selectedItemTitle.gameObject.SetActive(false);
            selectedItemUseButton.onClick.AddListener(UseItem);
            selectedItemDropButton.onClick.AddListener(DropItem);
            selectedItemUseButton.GetComponentInChildren<Text>().text = "Use/Equip";
            selectedItemDropButton.GetComponentInChildren<Text>().text = "Drop";
            selectedItemUseButton.gameObject.SetActive(false);
            selectedItemDropButton.gameObject.SetActive(false);
            selectedItemBackground.SetActive(false);
            dropdownFilter.onValueChanged.AddListener(delegate { Filter(dropdownFilter.value); });
            dropdownFilter.gameObject.SetActive(false);

            origin = gridLayout.transform.position;
            screen = new Vector2(Screen.width / 16, Screen.height / 9);
            pauseMenu = FindObjectOfType<PauseMenu>();
            pauseMenu.PausedMenu += PauseMenu_PausedMenu;

            inventory.Add(ItemData.CreateItem(0));
            inventory.Add(ItemData.CreateItem(1));
            inventory.Add(ItemData.CreateItem(2));

            inventory.Add(ItemData.CreateItem(100));
            inventory.Add(ItemData.CreateItem(101));
            inventory.Add(ItemData.CreateItem(102));

            inventory.Add(ItemData.CreateItem(200));
            inventory.Add(ItemData.CreateItem(201));
            inventory.Add(ItemData.CreateItem(202));

            inventory.Add(ItemData.CreateItem(300));
            inventory.Add(ItemData.CreateItem(301));

            inventory.Add(ItemData.CreateItem(400));
            inventory.Add(ItemData.CreateItem(401));
            inventory.Add(ItemData.CreateItem(402));

            inventory.Add(ItemData.CreateItem(500));
            inventory.Add(ItemData.CreateItem(501));
            inventory.Add(ItemData.CreateItem(502));

            inventory.Add(ItemData.CreateItem(600));
            inventory.Add(ItemData.CreateItem(601));
            inventory.Add(ItemData.CreateItem(602));

            inventory.Add(ItemData.CreateItem(700));

            CreateButtonInventory();
            AssignKey();
        }

        private void PauseMenu_PausedMenu(bool obj)
        {
            if (obj)
            {
                isGamePaused = true;
            }
            else
            {
                isGamePaused = false;
            }
        }

        public void AssignKey()
        {
            foreach (KeyValuePair<string, KeyCode> key in KeyBindings.keys)
            {
                if (key.Key.Equals("Inventory"))
                {
                    inventoryKey = key.Value;
                }
            }
        }

        // Update is called once per frame
        void Update()
        {
            if (Input.GetKeyDown(inventoryKey) && !isGamePaused)
            {
                showInventory = !showInventory;

                if (showInventory)
                {
                    Cursor.lockState = CursorLockMode.None;
                    Cursor.visible = true;
                    Time.timeScale = 0;
                    ShowInventory();
                    EnableScrollBar();
                }
                else
                {
                    Cursor.lockState = CursorLockMode.Locked;
                    Cursor.visible = false;
                    Time.timeScale = 1;
                    selectedItem = null;
                    CloseInventory();
                    DisableScrollBar();
                }
            }

            if (isGamePaused)
            {
                CloseInventory();
            }


            if (Input.GetKey(KeyCode.I))
            {
                AddButtonInventory(ItemData.CreateItem(Random.Range(0, 3)));
            }

            if (Input.GetKey(KeyCode.Keypad1))
            {
                if (selectedItem != null)
                {
                    selectedItem.Amount++;
                }
            }

            if (Input.GetKey(KeyCode.Keypad2))
            {
                money++;
            }

            if (Input.GetKeyDown(KeyCode.Keypad3))
            {
                foreach (Item item in inventory)
                {
                    Debug.Log(item.Name);
                }
            }
        }

        private void RepauseGame()
        {
            if (showInventory && Time.timeScale == 1)
            {
                Time.timeScale = 0;
            }
        }

        private void Filter(int value)
        {
            switch (value)
            {
                case 0:
                    {
                        foreach (Button button in parrallelButtonList)
                        {
                            button.gameObject.SetActive(true);
                        }
                    }
                    break;
                case 1:
                    {
                        for (int i = 0; i < inventory.Count; i++)
                        {
                            if (inventory[i].Type == ItemTypes.Armour)
                            {
                                parrallelButtonList[i].gameObject.SetActive(true);
                            }
                            else
                            {
                                parrallelButtonList[i].gameObject.SetActive(false);
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private int CountItems()
        {
            int count = 0;
            foreach (Item item in inventory)
            {
                count++;
            }
            return count;
        }

        private void ScrollBarSetup()
        {
            scrollbar.size = 18f / (float)CountItems();
        }

        private void Scroll(float value)
        {
            int scrollCapacity = (CountItems() - 18) * 30;
            gridLayout.transform.position = origin + new Vector3(0, scrollCapacity * value, 0);
        }

        private void EnableScrollBar()
        {
            if (CountItems() > 18)
            {
                ScrollBarSetup();
                scrollbar.gameObject.SetActive(true);
            }
            else
            {
                Debug.Log("Cannot enable scrollbar. Not enough items");
            }
        }

        private void DisableScrollBar()
        {
            scrollbar.gameObject.SetActive(false);
        }


        private void CreateButtonInventory()
        {
            foreach (Item item in inventory)
            {
                Button button = Instantiate(buttonPrefab, gridLayout.transform).GetComponent<Button>();
                button.GetComponentInChildren<Text>().text = item.Name;
                parrallelButtonList.Add(button);
                button.gameObject.SetActive(false);
            }
        }

        public void AddButtonInventory(Item item)
        {
            inventory.Add(item);
            Button button = Instantiate(buttonPrefab, gridLayout.transform).GetComponent<Button>();
            button.GetComponentInChildren<Text>().text = item.Name;
            parrallelButtonList.Add(button);
            if (showInventory)
            {
                button.gameObject.SetActive(true);
            }
            else
            {
                button.gameObject.SetActive(false);
            }
            ScrollBarSetup();
        }

        private void ShowInventory()
        {
            foreach (Button button in parrallelButtonList)
            {
                button.gameObject.SetActive(true);
                button.onClick.AddListener(delegate { SelectItem(button); });
            }
            dropdownFilter.gameObject.SetActive(true);
        }

        private void SelectItem(Button button)
        {
            Debug.Log("Button Clicked");
            foreach (Item item in inventory)
            {
                if (button.GetComponentInChildren<Text>().text == item.Name)
                {
                    selectedItem = item;
                    break;
                }
            }

            selectedItemImage.gameObject.SetActive(true);
            selectedItemImage.sprite = Sprite.Create(selectedItem.IconName, new Rect(0, 0, selectedItem.IconName.width, selectedItem.IconName.height), new Vector2(0, 0));
            selectedItemTitle.gameObject.SetActive(true);
            selectedItemTitle.text = selectedItem.Name;
            selectedItemDescription.gameObject.SetActive(true);
            selectedItemDescription.text = "Amount: " + selectedItem.Amount + "\n\n" + selectedItem.Description;
            selectedItemDropButton.gameObject.SetActive(true);
            selectedItemUseButton.gameObject.SetActive(true);
            selectedItemBackground.SetActive(true);
        }

        void UseItem()
        {
            Debug.Log("Used " + selectedItem.Name);
            switch (selectedItem.Type)
            {
                case ItemTypes.Armour:

                    break;
                case ItemTypes.Weapon:

                    if (equippedItems[1].equippedItem == null || selectedItem.Name != equippedItems[1].name)
                    {
                        // Equip
                        if (equippedItems[1].equippedItem != null)
                        {
                            Destroy(equippedItems[1].equippedItem);
                        }
                        equippedItems[1].equippedItem = Instantiate(selectedItem.MeshName, equippedItems[1].location);
                        equippedItems[1].name = selectedItem.Name;
                    }
                    else
                    {
                        // Unequip
                        Destroy(equippedItems[1].equippedItem);
                        equippedItems[1].equippedItem = null;
                        equippedItems[1].name = "";
                    }
                    break;
                case ItemTypes.Potion:

                    break;
                case ItemTypes.Food:

                    break;
                case ItemTypes.Ingredient:

                    break;
                case ItemTypes.Craftable:

                    break;
                case ItemTypes.Material:

                    break;
                default:
                    break;
            }
        }

        void DropItem()
        {
            Debug.Log("Dropped " + selectedItem.Name);
            // Check if the item is equipped.
            for (int i = 0; i < equippedItems.Length; i++)
            {
                if (equippedItems[i].equippedItem != null && selectedItem.Name == equippedItems[i].name)
                {
                    Destroy(equippedItems[i].equippedItem);
                }
            }

            // If item is equipped, remove equipment

            GameObject itemToDrop = Instantiate(selectedItem.MeshName, dropLocation.position, Quaternion.identity);
            // Spawn item at drop location
            itemToDrop.name = selectedItem.Name;
            itemToDrop.AddComponent<Rigidbody>().useGravity = true;

            // if have stacks of it
            if (selectedItem.Amount > 1)
            {
                // just remove one stack of it
                selectedItem.Amount--;
            }
            else
            {
                // Delete it
                RemoveItemAndButton(selectedItem);
                selectedItem = null;
                return;
            }
        }

        private void RemoveItemAndButton(Item item)
        {
            Button buttonToBeRemoved = null;
            inventory.Remove(item);
            foreach (Button button in parrallelButtonList)
            {
                if (item.Name == button.GetComponentInChildren<Text>().text)
                {
                    buttonToBeRemoved = button;
                }
            }
            parrallelButtonList.Remove(buttonToBeRemoved);
            Destroy(buttonToBeRemoved.gameObject);
            CloseSelectedItem();
            ScrollBarSetup();
            EnableScrollBar();
        }

        private void CloseInventory()
        {
            foreach (Button button in parrallelButtonList)
            {
                button.gameObject.SetActive(false);
            }
            dropdownFilter.gameObject.SetActive(false);
            CloseSelectedItem();
        }

        void CloseSelectedItem()
        {
            selectedItem = null;

            scrollbar.gameObject.SetActive(false);
            selectedItemImage.gameObject.SetActive(false);
            selectedItemImage.sprite = null;
            selectedItemTitle.gameObject.SetActive(false);
            selectedItemTitle.text = "";
            selectedItemDescription.gameObject.SetActive(false);
            selectedItemDescription.text = "";
            selectedItemDropButton.gameObject.SetActive(false);
            selectedItemUseButton.gameObject.SetActive(false);
            selectedItemBackground.SetActive(false);
        }
    }
}
